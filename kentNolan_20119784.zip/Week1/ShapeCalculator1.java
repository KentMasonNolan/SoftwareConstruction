package Week1;

public class ShapeCalculator1 {

    public static void main(String[] args) {
        Circle cirObj = new Circle("cirObj");
        cirObj.setRadius(2.5);

        Rectangle recObj = new Rectangle("recObj");
        recObj.setHeight(16.5);
        recObj.setWidth(12);

        cirObj.printInfo();
        recObj.printInfo();


    }
}
